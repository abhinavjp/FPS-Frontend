declare var styles: any;

export = styles;
